import sqlite3
def create_db():
    con=sqlite3.connect(database=r'Final Project.db')
    cur=con.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS Members(MembersID INTEGER PRIMARY KEY AUTOINCREMENT,Name text,Gender text,Contact text,Dob text,Doj text,Email text,Password text,UserType text,Address text)")
    con.commit()
    
    cur.execute("CREATE TABLE IF NOT EXISTS ROOMS(RoomId INTEGER PRIMARY KEY AUTOINCREMENT, Name text, Paymenttype text,Paymentamount text, currency type text, projectorneeded text, chairs needed text, address text) ")
    con.commit()
    
    cur.execute("CREATE TABLE IF NOT EXISTS payments(PaymentType text,PaymentAmmount text,CurrencyType text)")
    con.commit()

    cur.execute("CREATE TABLE IF NOT EXISTS contact(Name text, Email text, position text)")
    con.commit()
    
    cur.execute("CREATE TABLE IF NOT EXISTS Reserve(RoomId INTEGER PRIMARY KEY AUTOINCREMENT,FirstName text,Middlename text,LastName text,Contact text,Email text,Password text,AmountofStud text,AmountofTeacher text,AmountofTime text,RoomType text)")
    con.commit()
    
create_db()