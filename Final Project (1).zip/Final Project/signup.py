from tkinter import *
from PIL import ImageTk, Image
from tkinter import ttk
from tkinter import messagebox
class Signup_System:
    def __init__(self,root):
        self.root=root
        self.root.title("Sign Up |Developed in ITC 310 clsss")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#f0f0f0")
        #====images====
        self.phone_image=ImageTk.PhotoImage(file="images/phone.png")
        self.lbl_phone_image=Label(self.root,image=self.phone_image,bd=0).place(x=200,y=50)
    
        #======Signup Frame=====
        Signup_frame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        Signup_frame.place(x=520,y=80,width=500,height=600)
        
        title=Label(Signup_frame,text="Sign Up",font=("Elephant",30,"bold"),bg="white").place(x=0,y=30,relwidth=1)
        
        lbl_user=Label(Signup_frame,text="Username",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=100)
        self.username=StringVar()
        self.password=StringVar()
        self.firstname=StringVar()
        self.Email=StringVar()
        self.PhoneNumber=StringVar()
        txt_username=Entry(Signup_frame,textvariable=self.username,font=("times new roman",15),bg="#ECECEC").place(x=50,y=140,width=400,height=35)
        
        
        lbl_passwrod=Label(Signup_frame,text="Password",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=190)
        txt_password=Entry(Signup_frame,textvariable=self.password,show="*",font=("times new roman",15),bg="#ECECEC").place(x=50,y=230,width=400,height=35)
        
        lbl_firstname=Label(Signup_frame,text="FirstName",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=280)
        txt_firstname=Entry(Signup_frame,textvariable=self.firstname,font=("times new roman",15),bg="#ECECEC").place(x=50,y=320,width=400,height=35)
        
        lbl_Email=Label(Signup_frame,text="Email",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=370)
        txt_Email=Entry(Signup_frame,textvariable=self.Email,font=("times new roman",15),bg="#ECECEC").place(x=50,y=410,width=400,height=35)
        
        lbl_PhoneNumber=Label(Signup_frame,text="PhoneNumber",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=460)
        txt_PhoneNumber=Entry(Signup_frame,textvariable=self.PhoneNumber,font=("times new roman",15),bg="#ECECEC").place(x=50,y=500,width=400,height=35)
        
        
        
        btn_SignUp=Button (Signup_frame,text="SignUp",font=("Arial Rounded MT Bold",15),command=self.sign_up, bg="#00B0F0",activebackground="#00B0F0",fg="white",activeforeground="white",cursor="hand2").place(x=300,y=545,width=150,height=45)         
        btn_Login=Button(Signup_frame,text="Log In",font=("Arial Rounded MT Bold",15),bg="#00B0F0",activebackground="#00B0F0",fg="white",activeforeground="white",cursor="hand2").place(x=50,y=545,width=150,height=45)
        
    def sign_up(self):
        if self.firstname.get()==""or self.username.get()=="" or self.Email.get() or self.password.get():
            messagebox.showerror("Error", "All fields are required")
        elif self.Email.get():
            messagebox.showerror("all fields are required ")
        else:
            messagebox.showinfo("registerd")



            
        
root=Tk()
obj=Signup_System(root)
root.mainloop()