from tkinter import*
from PIL import Image, ImageTk 

from PIL import Image


class TutorialRoomClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1350x700+0+0")
        self.root.title("AUAF Room booking system | Developed in ITC 310 class")
        self.root.config(bg="#eef0ef")
        self.root.focus_force()
    

   
        title=Label(self.root,text="Tutorial Room",compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
      
##################left menu frame

        
        self.MenuLogo=Image.open("images/TutorialRoom.png")
        self.MenuLogo=self.MenuLogo.resize((600,500),Image.ANTIALIAS)
        self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
        
        LeftMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white")
        LeftMenu.place(x=100,y=102,width=600,height=500)

        lbl_menuLogo=Label(LeftMenu,image=self.MenuLogo)
        lbl_menuLogo.pack(side=TOP,fill=X)
        
        self.icon_side=PhotoImage(file="images/TutorialRoom.png")
        
        lbl_menu=Label(LeftMenu,text="Menu",font=("times new roman",20),bg="#009688").pack(side=RIGHT,fill=X)


        ##############right menu################33333
        RightMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white",)
        RightMenu.place(x=705,y=185,width=600,height=390)

       

        self.lbl_Members=Label(self.root,text="*There are 5 Tutorial Rooms in the university\n * These Rooms  has the capicity to host 10 students\n *projectors are also available in Tutorial Rooms",bd=5,relief=RIDGE,bg="light grey",fg="black",font=("goudy old style",20,"bold"))
        self.lbl_Members.place(x=705,y=185,height=390,width=600)
        
       

        #===btn_logout===#

        btn_Exit=Button(root,text="Exit",command=self.Exit,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=BOTTOM,padx=20,pady=20)

    def Exit(self):
        self.root.destroy()

     

    
if __name__=="__main__":
    root=Tk()
    obj=TutorialRoomClass(root)
    root.mainloop()
