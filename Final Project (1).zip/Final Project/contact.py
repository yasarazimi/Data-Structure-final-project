from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
import sqlite3
import tkinter.messagebox



class contactClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("AUAF Room booking system | Developed in ITC 310 clsss")
        self.root.config(bg="white")
        self.root.focus_force()
        #==================================
        #===title===#
        self.icon_title=PhotoImage(file="images/Bookroom.png")
        title=Label(self.root,text="AUAF Contacts",image=self.icon_title,compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        # All Variables=====
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()  
        
        self.varContact_Details=StringVar()
        self.varManager=StringVar()
        self.varExcecutive_Details=StringVar()
        self.varStudent_Affiar=StringVar()
        self.varStudent_Finance=StringVar()
        #====SearchFrame====
        SearchFrame=LabelFrame(self.root,text="Search Contacts",font=("goudy old style",15,"bold"),bd=2,relief=RIDGE,bg="white")
        SearchFrame.place(x=0,y=75,relwidth=1,height=70)
        
        #=====Options===
        cmb_search=ttk.Combobox(SearchFrame,textvariable=self.var_searchby,values=("Select","Contacts"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_search.place(x=305,y=10,width=180)
        cmb_search.current(0)
        
        txt_search=Entry(SearchFrame,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=490,y=10)
        btn_search=Button(SearchFrame,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=700,y=9,width=150,height=30)
        
        #===title===
        title=Label(self.root,text="Contact Details",font=("goudy old style",15),bg="#FA8072",fg="white").place(x=0,y=151,relwidth=1)
        
        
        #====content=====
        self.MenuLogo=Image.open("images/hotelstatus.png")
        self.MenuLogo=self.MenuLogo.resize((100,100),Image.ANTIALIAS)
        self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
        
        LeftMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white")
        LeftMenu.place(x=0,y=102,width=200,height=565)

        lbl_menuLogo=Label(LeftMenu,image=self.MenuLogo)
        lbl_menuLogo.pack(side=TOP,fill=X)
        
        self.icon_side=PhotoImage(file="images/side.png")
        
        lbl_menu=Label(LeftMenu,text="Contacts",font=("times new roman",20),bg="#009688").pack(side=TOP,fill=X)

        #======Button=====

        btn_Director=Button(self.root,text="Director",font=("times new roman",15,"bold"),command=self.Director,bg="light blue",cursor="hand2").place(x=1,y=247,height=50,width=197)
        btn_Manger=Button(self.root,text="Manager",font=("times new roman",15,"bold"),command=self.Manager,bg="light blue",cursor="hand2").place(x=1,y=297,height=50,width=197)
        btn_Executive=Button(self.root,text="Excecutive",font=("times new roman",15,"bold"),command=self.Student,bg="light blue",cursor="hand2").place(x=1,y=347,height=50,width=197)
        btn_Student=Button(self.root,text="Students Affair",font=("times new roman",15,"bold"),command=self.Executive,bg="light blue",cursor="hand2").place(x=1,y=397,height=50,width=197)
        btn_Finance=Button(self.root,text="Students Finance",font=("times new roman",15,"bold"),command=self.Finance,bg="light blue",cursor="hand2").place(x=1,y=447,height=50,width=197)     
        
        #======Main frame Row1=====
        MainMenu=Frame(self.root,bd=2,relief=RIDGE,bg="#eef0ef")
        MainMenu.place(x=201,y=181,width=898,height=317)
        
        #=====First Contact Director=====
        lbl_Contact_details=Label(self.root,text="Director",font=("times new roman",15,"bold"),bg="black",fg="white").place(x=205,y=185)
        lbl_Contact_details=Label(self.root,text="MR. Yasar Azimi",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=205,y=220)
        lbl_Contact_details=Label(self.root,text="Mail : yasarazimi@gmail.com",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=205,y=255)

        lbl_Manager=Label(self.root,text="Manager",font=("times new roman",15,"bold"),bg="black",fg="white").place(x=505,y=185)
        lbl_Manager=Label(self.root,text="MR. Ali reza",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=505,y=220)
        lbl_Manager=Label(self.root,text="Mail : alireza@gmail.com",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=505,y=255)
        
        lbl_Excecutive_Details=Label(self.root,text="Excecutive",font=("times new roman",15,"bold"),bg="black",fg="white").place(x=205,y=390)
        lbl_Excecutive_Details=Label(self.root,text="MR. Tasal Sahibzada",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=205,y=425)
        lbl_Excecutive_Details=Label(self.root,text="Mail : tasalSahibzada@gmail.com",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=205,y=460)
        
        lbl_Student_Affiar=Label(self.root,text="Student Affair",font=("times new roman",15,"bold"),bg="black",fg="white").place(x=505,y=390)
        lbl_Student_Affiar=Label(self.root,text="DR.Ala Abdul Hakim",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=505,y=425)
        lbl_Student_Affiar=Label(self.root,text="Mail : Studentaffair@AUAF.com",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=505,y=460)
        
        lbl_Student_Fincance=Label(self.root,text="Student Finance",font=("times new roman",15,"bold"),bg="black",fg="white").place(x=805,y=185)
        lbl_Student_Fincance=Label(self.root,text="Ms. Sara Jhnoson",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=805,y=220)
        lbl_Student_Fincance=Label(self.root,text="Mail : sarajhonsona@gmail.com",font=("times new roman",15,"bold"),bg="grey",fg="white").place(x=805,y=255)
   
    

    def Director(self):
        tkinter.messagebox.showinfo("More Details","He has free time from 2AM:10 PM \n contact number:+937684291844 ")
    def Manager(self):
        tkinter.messagebox.showinfo("More Details","He has free time from 6AM:11 PM \n contact number:+937544291844 ")
    def Finance(self):
        tkinter.messagebox.showinfo("More Details","He has free time from 4AM:12 PM \n contact number:+937689851844 ")
    def Executive (self):
        tkinter.messagebox.showinfo("More Details","He has free time from 7AM:1 PM \n contact number:+93139291844 ")
    def Student(self):
        tkinter.messagebox.showinfo("More Details","He has free time from 5AM:8 PM \n contact number:+937687691844 ")


    def search(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_searchby.get()=="Select":
                messagebox.showerror("Error","Select search by option", parent=self.root)
            elif self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Search input required", parent=self.root)
            else:
                cur.execute("select * from members where "+self.var_searchby.get()+" LIKE '%"+self.var_searchtxt.get()+"%'")
                rows=cur.fetchall()
                if len(rows)!=0:
                    self.RoomsTable.delete(*self.RoomsTable.get_children())
                    for row in rows:
                        self.RoomsTable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No Record Found!!!", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
            


if __name__=="__main__":
    root=Tk()
    obj=contactClass(root)
    root.mainloop()

    
    