from tkinter import *
from PIL import ImageTk, Image
from tkinter import ttk
from tkinter import messagebox
import sqlite3
import os
class Login_System:
    def __init__(self,root):
        self.root=root
        self.root.title("Login System |Developed in ITC 310 class")
        self.root.geometry("1350x700+0+0")
        self.root.config(bg="#f0f0f0")
        #====images====
        self.AUAF_image=ImageTk.PhotoImage(file="images/student6.png")
        self.lbl_phone_image=Label(self.root,image=self.AUAF_image,bd=0).place(x=200,y=50)
    
        #======Login Frame=====
        self.username=StringVar()
        self.password=StringVar()

        login_frame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        login_frame.place(x=520,y=80,width=350,height=460)
        
        title=Label(login_frame,text="Login System",font=("Elephant",30,"bold"),bg="white").place(x=0,y=30,relwidth=1)
        
        lbl_user=Label(login_frame,text="Username",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=100)
        txt_username=Entry(login_frame,textvariable=self.username,font=("times new roman",15),bg="#ECECEC").place(x=50,y=140,width=250,height=35)
        
        
        lbl_passwrod=Label(login_frame,text="Password",font=("Andalus",15),bg="white",fg="#767171").place(x=50,y=190)
        txt_password=Entry(login_frame,textvariable=self.password,show="*",font=("times new roman",15),bg="#ECECEC").place(x=50,y=230,width=250,height=35)
                
        btn_login=Button(login_frame,command=self.login,text="Log In",font=("Arial Rounded MT Bold",15),bg="#00B0F0",activebackground="#00B0F0",fg="white",activeforeground="white",cursor="hand2").place(x=50,y=300,width=250,height=45)
        
        hr=Label(login_frame,bg="lightgray").place(x=50,y=370,width=250,height=2)
        or_=Label(login_frame,text="OR",bg="white",fg="lightgray",font=("times new roman",15,"bold")).place(x=150,y=355)
        
        # btn_forget=Button(login_frame,text="Forget Password?",font=("times new roman",13),bg="white",fg="#00759E",bd=0,activebackground="white",activeforeground="#00759E").place(x=100,y=390)
        
        
        #=======Frame2==========
        # register_frame=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        # register_frame.place(x=520,y=560,width=350,height=60)
 
        # lbl_re=Label(register_frame,text="Don't have an account ?",font=("times new roman",13),bg="white").place(x=40,y=20)
        # btn_signup=Button(register_frame,text="Sign Up",font=("times new roman",13,"bold"),bg="white",fg="#00759E",bd=0,activebackground="white",activeforeground="#00759E").place(x=200,y=17)
        
        
        
    def login(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.username.get()=="" or self.password.get()=="":
                messagebox.showerror('Error', "All fields are required",parent=self.root)
            else:
                cur.execute("select UserType from members where Name=? AND Password=?",(self.username.get(),self.password.get()))
                user=cur.fetchone()
                if user==None:
                    messagebox.showerror('Error', "Invalid User/pass",parent=self.root)
                else:
                    if user[0]=="Admin":
                        self.root.destroy()
                        os.system("python dashboard.py")
                    else:
                        self.root.destroy()
                        os.system("python room.py")
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)

            
        
root=Tk()
obj=Login_System(root)
root.mainloop()