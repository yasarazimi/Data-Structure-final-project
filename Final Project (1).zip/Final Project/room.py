from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
import sqlite3
import tkinter as tk
from PIL import ImageTk


from LectureHall import lectureClass
from ExamHall import ExamHallClass
from MainHall import MainHallClass
from Design import DesignStudioClass
from MeetingRoom import MeetingRoomClass
from TutorialRoom import TutorialRoomClass
class roomClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1100x637+220+130")
        self.root.title("AUAF Room booking system | Developed in ITC 310 clsss")
        self.root.config(bg="white")
        self.root.focus_force()
        #==================================
        #===title===#
        self.icon_title=PhotoImage(file="images/Bookroom.png")
        title=Label(self.root,text="AUAF Rooms Check",image=self.icon_title,compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        # All Variables=====
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()  
        
        self.var_Room_Type=StringVar()
        self.var_RoomId=StringVar()
        self.var_Room_Name=StringVar()
        self.var_Date_of_Reservation=StringVar()    
        self.var_Chairs_Needed=StringVar()
        self.var_Tables_Needed=StringVar()
        self.var_Projectors_Needed=StringVar()
        self.var_Other_Changes=StringVar()
        self.var_Reserve=StringVar()        

        self.var_paymenttype=StringVar()
        self.var_paymentamount=StringVar()
        self.var_currency=StringVar()
        self.var_projectorsneeded=StringVar()
        self.var_charis=StringVar()
        self.var_address=StringVar()


        #====SearchFrame====
        SearchFrame=LabelFrame(self.root,text="Search Rooms",font=("goudy old style",15,"bold"),bd=2,relief=RIDGE,bg="white")
        SearchFrame.place(x=0,y=75,relwidth=1,height=70)
        
        #=====Options===
        self.roomstable=ttk.Combobox(SearchFrame,textvariable=self.var_searchby,values=("Select","ID","RoomName"),state='readonly',justify=CENTER,font=("goudy old style",15))
        self.roomstable.place(x=305,y=10,width=180)
        self.roomstable.current(0)
        
        txt_search=Entry(SearchFrame,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=490,y=10)
        btn_search=Button(SearchFrame,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=700,y=9,width=150,height=30)
        
        #===title===
        title=Label(self.root,text="Room Details",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=0,y=151,relwidth=1)
        
        
        #====content=====
        self.MenuLogo=Image.open("images/hotelstatus.png")
        self.MenuLogo=self.MenuLogo.resize((100,100),Image.ANTIALIAS)
        self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
        
        LeftMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white")
        LeftMenu.place(x=0,y=183,width=200,height=565)   ####102

        lbl_menuLogo=Label(LeftMenu,image=self.MenuLogo)
        lbl_menuLogo.pack(side=TOP,fill=X)
        
        self.icon_side=PhotoImage(file="images/side.png")
        
        lbl_menu=Label(LeftMenu,text="Rooms",font=("times new roman",20),bg="#009688").pack(side=TOP,fill=X)

        #======Button=====




        btn_Lecture=Button(self.root,text="Lecture Hall",command=self.lecture,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=328,height=50,width=197)
        btn_MainHall=Button(self.root,text="Main Hall",command=self.MainHall,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=380,height=50,width=197)
        btn_ExamHall=Button(self.root,text="ExamHall",command=self.ExamHall,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=432,height=50,width=197)
        btn_DesignStudio=Button(self.root,text="Design Studio",command=self.DesignStudio,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=484,height=50,width=197)
        btn_MeetingRoom=Button(self.root,text="Meeting Room",command=self.MeetingRoom,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=536,height=50,width=197)     
        btn_Tutorial=Button(self.root,text="Tuttorial Room",command=self.TutorialRoom,font=("times new roman",15,"bold"),bg="#E0E0FF",cursor="hand2").place(x=1,y=586,height=50,width=197)
        
   
    
        
        #======Main frame Row1=====
        MainMenu=Frame(self.root,bd=2,relief=RIDGE,bg="white")
        MainMenu.place(x=201,y=181,width=898,height=450)
        lbl_Room_Name=Label(self.root,text="Rooms Name",font=("times new roman",15,"bold"),bg="white").place(x=203,y=230,width=180,height=50)
        txt_Room_Name=Entry(self.root,textvariable=self.var_Room_Name,font=("times new roman",15,"bold"),bg="lightyellow").place(x=401,y=230,width=180,height=50)

        lbl_Chairs_Needed=Label(self.root,text="Chairs Needed",font=("times new roman",15,"bold"),bg="white").place(x=720,y=230,width=180,height=50) 
        cmb_Chairs_Needed=ttk.Combobox(self.root,textvariable=self.var_Chairs_Needed,values=("Select","Yes","No"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_Chairs_Needed.place(x=910,y=230,width=180,height=50)
        cmb_Chairs_Needed.current(0)        
        #======Row2=====
        lbl_Date_of_Reservation=Label(self.root,text="Date of Reservation",font=("times new roman",15,"bold"),bg="white").place(x=203,y=297,width=180,height=50)
        txt_Date_of_Reservation=Entry(self.root,textvariable=self.var_Date_of_Reservation,font=("times new roman",15,"bold"),bg="lightyellow").place(x=401,y=297,width=180,height=50)
        
        lbl_Tables_Needed=Label(self.root,text="Tables Needed",font=("times new roman",15,"bold"),bg="white").place(x=720,y=355,width=180,height=50) 
        cmb_Tables_Needed=ttk.Combobox(self.root,textvariable=self.var_Chairs_Needed,values=("Select","Yes","No"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_Tables_Needed.place(x=910,y=355,width=180,height=50)
        cmb_Tables_Needed.current(0)        
        #======Row3=====
        lbl_Room_Type=Label(self.root,text="RoomsType",font=("times new roman",15,"bold"),bg="white").place(x=203,y=355,width=180,height=50)
        cmb_Room_Type=ttk.Combobox(self.root,textvariable=self.var_Room_Type,values=("Select","Main Hall","Lecture Room","Tutorial Room"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_Room_Type.place(x=401,y=355,width=180,height=50)
        cmb_Room_Type.current(0)        
        
        lbl_Tables_Needed=Label(self.root,text="Projector Needed",font=("times new roman",15,"bold"),bg="white").place(x=720,y=297,width=180,height=50) 
        cmb_Tables_Needed=ttk.Combobox(self.root,textvariable=self.var_Projectors_Needed,values=("Select","Yes","No"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_Tables_Needed.place(x=910,y=297,width=180,height=50)
        cmb_Tables_Needed.current(0)               
        #=========Row4==========
        lbl_RoomId=Label(self.root,text="Room-ID",font=("times new roman",15,"bold"),bg="white").place(x=203,y=450,width=180,height=50) 
        txt_RoomId=Entry(self.root,textvariable=self.var_RoomId,font=("times new roman",15,"bold"),bg="lightyellow").place(x=400,y=450,width=180,height=50)
        
       
        btn_Clear=Button(self.root,text="Clear",font=("times new roman",15,"bold"),bg="#f44336",command=self.clear,fg="white",cursor="hand2").place(x=910,y=490,height=50,width=180)
        btn_Reserve=Button(self.root,text="Reserve",command=self.Reserve,font=("times new roman",15,"bold"),bg="#2196f3",fg="white",cursor="hand2").place(x=910,y=550,height=50,width=180)

           
    def clear(self):
        self.var_Room_Type.set("Select")
        self.var_Room_Name.set("")
        self.var_Date_of_Reservation.set("")
        self.var_searchtxt.set("")
        self.var_searchby.set("Select")
        self.var_RoomId.set("")
        
   




    def search(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_searchby.get()=="Select":
                messagebox.showerror("Error","Select search by option", parent=self.root)
            elif self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Search input required", parent=self.root)
            else:
                cur.execute("select * from room where "+self.var_searchby.get()+" LIKE '%"+self.var_searchtxt.get()+"%'")
                rows=cur.fetchall()
                if len(rows)!=0:
                    self.roomstable.delete(*self.roomstable.get())
                    for row in rows:
                        self.roomstable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No Record Found!!!", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
            
    def Reserve(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_RoomId.get()=="":
                messagebox.showerror("Error","RoomId Must be required",parent=self.root)
            else:
                cur.execute("Select * from ROOMS where RoomId=?",(self.var_RoomId.get(),))
                row=cur.fetchone()
                if row!=None:
                    messagebox.showerror("Error","This Room already Assigned Try a different roomiD",parent=self.root)
                else:
                    cur.execute("Insert into ROOMS(RoomId,Name,Paymenttype,paymentamount,currency,projectorneeded,chairs,address) values(?,?,?,?,?,?,?,?)",(
                                        self.var_RoomId.get(),
                                        self.var_Room_Type.get(),
                                        self.var_Chairs_Needed.get(),
                                        self.var_Room_Name.get(),
                                        self.var_Tables_Needed.get(),
                                        self.var_projectorsneeded.get(),
                                        self.var_Date_of_Reservation.get(),
                                        self.var_Date_of_Reservation.get(),
                                        
                    ))
                    con.commit()
                    messagebox.showinfo("success","Room added successfully",parent=self.root)
                    
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
    
    def lecture(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=lectureClass(self.new_win)
    
    def MainHall(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=MainHallClass(self.new_win)

    def DesignStudio(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=DesignStudioClass(self.new_win)
    def ExamHall(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=ExamHallClass(self.new_win)

    def MeetingRoom(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=MeetingRoomClass(self.new_win)

    def TutorialRoom(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=TutorialRoomClass(self.new_win)
        
        

if __name__=="__main__":
    root=Tk()
    obj=roomClass(root)

    root.mainloop()

    
    