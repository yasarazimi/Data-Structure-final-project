from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
import sqlite3
class membersClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("AUAF Room booking system | Developed in ITC 310 clsss")
        self.root.config(bg="white")
        self.root.focus_force()
        #==================================
        # All Variables=====
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()  
        
        self.var_Member_id=StringVar()
        self.var_Gender=StringVar()
        self.var_Contact=StringVar()
        self.var_Name=StringVar()
        self.var_Dob=StringVar()
        self.var_Doj=StringVar()
        self.var_Email=StringVar()  
        self.var_Password=StringVar()  
        self.var_UserType=StringVar()     
        self.var_Address=StringVar()     
                
        #====SearchFrame====
        SearchFrame=LabelFrame(self.root,text="Search Members",font=("goudy old style",12,"bold"),bd=2,relief=RIDGE,bg="white")
        SearchFrame.place(x=250,y=20,width=600,height=70)
        
        #=====Options===
        cmb_search=ttk.Combobox(SearchFrame,textvariable=self.var_searchby,values=("Select","ID","Name","Contact","Email"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_search.place(x=10,y=10,width=180)
        cmb_search.current(0)
        
        txt_search=Entry(SearchFrame,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=200,y=10)
        btn_search=Button(SearchFrame,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=410,y=9,width=150,height=30)
        
        #===title===
        title=Label(self.root,text="Details",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=50,y=100,width=1000)
        
        
        #====content=====
        #======Row1=====
        lbl_Memid=Label(self.root,text="MembersID",font=("goudy old style",15),bg="white").place(x=45,y=150)
        lbl_gender=Label(self.root,text="Gender",font=("goudy old style",15),bg="white").place(x=350,y=150)
        lbl_contact=Label(self.root,text="Contact",font=("goudy old style",15),bg="white").place(x=750,y=150)
        
        txt_Memid=Entry(self.root,textvariable=self.var_Member_id,font=("goudy old style",15),bg="lightyellow").place(x=150,y=150,width=180)
        cmb_gender=ttk.Combobox(self.root,textvariable=self.var_Gender,values=("Select","Male","Female","Other"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_gender.place(x=500,y=150,width=180)
        cmb_gender.current(0)        
        txt_contact=Entry(self.root,textvariable=self.var_Contact,font=("goudy old style",15),bg="lightyellow").place(x=850,y=150,width=180)

        #======Row2=====
        lbl_Name=Label(self.root,text="Name",font=("goudy old style",15),bg="white").place(x=50,y=190)
        lbl_DOB=Label(self.root,text="Date of Birth",font=("goudy old style",15),bg="white").place(x=350,y=190)
        lbl_DOJ=Label(self.root,text="D.O.J",font=("goudy old style",15),bg="white").place(x=750,y=190)
        
        txt_name=Entry(self.root,textvariable=self.var_Name,font=("goudy old style",15),bg="lightyellow").place(x=150,y=190,width=180)
        txt_DOB=Entry(self.root,textvariable=self.var_Dob,font=("goudy old style",15),bg="lightyellow").place(x=500,y=190,width=180)
        txt_DOJ=Entry(self.root,textvariable=self.var_Doj,font=("goudy old style",15),bg="lightyellow").place(x=850,y=190,width=180)

        #======Row3=====
        lbl_Email=Label(self.root,text="Email",font=("goudy old style",15),bg="white").place(x=45,y=230)
        lbl_Password=Label(self.root,text="Password",font=("goudy old style",15),bg="white").place(x=350,y=230)
        lbl_Usertype=Label(self.root,text="UserType",font=("goudy old style",15),bg="white").place(x=750,y=230)
        
        txt_Email=Entry(self.root,textvariable=self.var_Email,font=("goudy old style",15),bg="lightyellow").place(x=150,y=230,width=180)
        txt_Password=Entry(self.root,textvariable=self.var_Password,font=("goudy old style",15),bg="lightyellow").place(x=500,y=230,width=180)
        cmb_UserType=ttk.Combobox(self.root,textvariable=self.var_UserType,values=("Member","Staff"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_UserType.place(x=850,y=230,width=180)
        cmb_UserType.current(0)              
        
        #======Row4=====
        lbl_Address=Label(self.root,text="Address",font=("goudy old style",15),bg="white").place(x=50,y=270)
        self.txt_Address=Text(self.root,font=("goudy old style",15),bg="lightyellow")
        self.txt_Address.place(x=150,y=270,width=300,height=60)
        
        
        #======Button=====
        btn_add=Button(self.root,text="Save",command=self.add,font=("goudy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=500,y=305,width=110,height=28)
        btn_Update=Button(self.root,text="Update",command=self.update,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=620,y=305,width=110,height=28)
        btn_Delete=Button(self.root,text="Delete",command=self.delete,font=("goudy old style",15),bg="#f44336",fg="white",cursor="hand2").place(x=740,y=305,width=110,height=28)
        btn_Clear=Button(self.root,text="Clear",command=self.clear,font=("goudy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=860,y=305,width=110,height=28)
        
        
        #======Memebrs Details, Shown in Tree View==========
        
        Members_frame=Frame(self.root,bd=3,relief=RIDGE)
        Members_frame.place(x=0,y=350,relwidth=1,height=150)
        
        scrolly=Scrollbar(Members_frame,orient=VERTICAL)
        scrollx=Scrollbar(Members_frame,orient=HORIZONTAL)        
        
        self.MembersTable=ttk.Treeview(Members_frame,columns=("MembersID","Name","Gender","Contact","Dob","Doj","Email","Password","UserType","Address"),yscrollcommand=scrolly.set,xscrollcommand=scrollx.set)
        scrollx.pack(side=BOTTOM,fill=X)
        scrolly.pack(side=RIGHT,fill=Y)    
        scrollx.config(command=self.MembersTable.xview)
        scrolly.config(command=self.MembersTable.yview)
        
        self.MembersTable.heading("MembersID",text="MembersID")
        self.MembersTable.heading("Name",text="Name")
        self.MembersTable.heading("Gender",text="Gender")
        self.MembersTable.heading("Contact",text="Contact")
        self.MembersTable.heading("Dob",text="Dob")
        self.MembersTable.heading("Doj",text="Doj")
        self.MembersTable.heading("Email",text="Email")
        self.MembersTable.heading("Password",text="Password")
        self.MembersTable.heading("UserType",text="UserType")
        self.MembersTable.heading("Address",text="Address")       


        self.MembersTable["show"]="headings"

        self.MembersTable.column("MembersID",width=90)
        self.MembersTable.column("Name",width=100)
        self.MembersTable.column("Gender",width=100)
        self.MembersTable.column("Contact",width=100)
        self.MembersTable.column("Dob",width=100)
        self.MembersTable.column("Doj",width=100)
        self.MembersTable.column("Email",width=100)
        self.MembersTable.column("Password",width=100)
        self.MembersTable.column("UserType",width=100)
        self.MembersTable.column("Address",width=300)       
        self.MembersTable.pack(fill=BOTH,expand=1)
        self.MembersTable.bind("<ButtonRelease-1>", self.get_data)
        
        self.show()
#=================================


    def add(self):
        
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_Member_id.get()=="":
                messagebox.showerror("Error","Members ID Must be required",parent=self.root)

        
            else:
                cur.execute("Select * from Members where Member=?",(self.var_Member_id.get(),))
                row=cur.fetchone()
                if row!=None:
                    messagebox.showerror("Error","This Employess ID already Assigned Try a different ID",parent=self.root)
                else:
                    cur.execute("Insert into Members(Member,Name,Gender,Contact,Dob,Doj,Email,Password,UserType,Address) values(?,?,?,?,?,?,?,?,?,?)",(
                                        self.var_Member_id.get(),
                                        self.var_Name.get(),
                                        self.var_Gender.get(),
                                        self.var_Contact.get(),
                                        
                                        self.var_Dob.get(),
                                        self.var_Doj.get(),
                                        
                                        self.var_Email.get(),
                                        self.var_Password.get(),
                                        self.var_UserType.get(),
                                        self.txt_Address.get('1.0',END),
                    ))
                    con.commit()
                    messagebox.showinfo("success","Member added successfully",parent=self.root)
                    self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
        
    def show(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            cur.execute("select * from Members")
            rows=cur.fetchall()
            self.MembersTable.delete(*self.MembersTable.get_children())
            for row in rows:
                self.MembersTable.insert('',END,values=row)
        
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
        
    def get_data(self,ev):
        f=self.MembersTable.focus()
        content=(self.MembersTable.item(f))    
        row=content['values']
      # print(row)        
        self.var_Member_id.set(row[0])
        self.var_Name.set(row[1])
        self.var_Gender.set(row[2])
        self.var_Contact.set(row[3])
                                        
        self.var_Dob.set(row[4])
        self.var_Doj.set(row[5])
                                        
        self.var_Email.set(row[6])
        self.var_Password.set(row[7])
        self.var_UserType.set(row[8])
        self.txt_Address.delete('1.0',END)
        self.txt_Address.insert(END,row[9])
 
    def update(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_Member_id.get()=="":
                messagebox.showerror("Error","Members ID Must be required",parent=self.root)
            else:
                cur.execute("Select * from Members where Member=?",(self.var_Member_id.get(),))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Invalid ID",parent=self.root)
                else:
                    cur.execute("Update Members set Name=?,Gender=?,Contact=?,Dob=?,Doj=?,Email=?,Password=?,UserType=?,Address=? where Member=?",(
                                        self.var_Name.get(),
                                        self.var_Gender.get(),
                                        self.var_Contact.get(),
                                        
                                        self.var_Dob.get(),
                                        self.var_Doj.get(),
                                        
                                        self.var_Email.get(),
                                        self.var_Password.get(),
                                        self.var_UserType.get(),
                                        self.txt_Address.get('1.0',END),
                                        self.var_Member_id.get(),
                    ))
                    con.commit()
                    messagebox.showinfo("success","Member Updated successfully",parent=self.root)
                    self.show()

        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
        
    def delete(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_Member_id.get()=="":
                messagebox.showerror("Error","Members ID Must be required",parent=self.root)
            else:
                cur.execute("Select * from Members where Member=?",(self.var_Member_id.get(),))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Invalid ID",parent=self.root)
                else:
                    op=messagebox.askyesno("Confirm","Do you really want to delete this data?",parent=self.root)
                    if op==True:
                        cur.execute("delete from Members where Member=?",(self.var_Member_id.get(),))
                        con.commit()
                        messagebox.showinfo("Delete","Member Deleted successfully",parent=self.root)
                        self.clear()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
           
    def clear(self):
        self.var_Member_id.set("")
        self.var_Name.set("")
        self.var_Gender.set("Select")
        self.var_Contact.set("")
                                        
        self.var_Dob.set("")
        self.var_Doj.set("")
                                        
        self.var_Email.set("")
        self.var_Password.set("")
        self.var_UserType.set("Admin")
        self.txt_Address.delete('1.0',END)
        # self.txt_Address.set("")
        self.var_searchtxt.set("")
        self.var_searchby.set("Select")
        self.show()             

    def search(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_searchby.get()=="Select":
                messagebox.showerror("Error","Select search by option", parent=self.root)
            elif self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Search input required", parent=self.root)
            else:
                cur.execute("select * from Members where "+self.var_searchby.get()+" LIKE '%"+self.var_searchtxt.get()+"%'")
                rows=cur.fetchall()
                if len(rows)!=0:
                    self.MembersTable.delete(*self.MembersTable.get_children())
                    for row in rows:
                        self.MembersTable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No Record Found!!!", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
            


if __name__=="__main__":
    root=Tk()
    obj=membersClass(root)
    root.mainloop()

    
    