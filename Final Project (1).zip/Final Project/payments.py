from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
import sqlite3
class paymentsClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1100x500+220+130")
        self.root.title("AUAF Room booking system | Developed in ITC 310 clsss")
        self.root.config(bg="white")
        self.root.focus_force()
        #==================================
        #===title===#
        self.icon_title=PhotoImage(file="images/Bookroom.png")
        title=Label(self.root,text="AUAF Payments",image=self.icon_title,compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        # All Variables=====
        self.var_searchby=StringVar()
        self.var_searchtxt=StringVar()  
        
        self.varPaymentType=StringVar()
        self.varPaymentAmmount=StringVar()
        self.varCurrencyType=StringVar()
        #====SearchFrame====
        SearchFrame=LabelFrame(self.root,text="Search Rooms",font=("goudy old style",15,"bold"),bd=2,relief=RIDGE,bg="white")
        SearchFrame.place(x=0,y=75,relwidth=1,height=70)
        
        #=====Options===
        cmb_search=ttk.Combobox(SearchFrame,textvariable=self.var_searchby,values=("Select","Payments"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_search.place(x=305,y=10,width=180)
        cmb_search.current(0)
        
        txt_search=Entry(SearchFrame,textvariable=self.var_searchtxt,font=("goudy old style",15),bg="lightyellow").place(x=490,y=10)
        btn_search=Button(SearchFrame,text="Search",command=self.search,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=700,y=9,width=150,height=30)
        
        #===title===
        title=Label(self.root,text="Payment Details",font=("goudy old style",15),bg="#FA8072",fg="white").place(x=0,y=151,height=90,relwidth=1)
        
        
        #====content=====
        self.MenuLogo=Image.open("images/hotelstatus.png")
        self.MenuLogo=self.MenuLogo.resize((100,100),Image.ANTIALIAS)
        self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
        
        LeftMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white")
        LeftMenu.place(x=0,y=102,width=200,height=565)

        lbl_menuLogo=Label(LeftMenu,image=self.MenuLogo)
        lbl_menuLogo.pack(side=TOP,fill=X)
        
        self.icon_side=PhotoImage(file="images/side.png")
        
        lbl_menu=Label(LeftMenu,text="Payments",font=("times new roman",20),bg="#eef0ef").pack(side=TOP,fill=X)

        #======Button=====

        btn_Payment_Type=Button(self.root,text=">>>>>>",font=("times new roman",20,"bold"),bg="#9A9ACD",fg="black",cursor="hand2").place(x=1,y=247,height=80,width=197)
        btn_Payment_Ammount=Button(self.root,text=">>>>>>",font=("times new roman",20,"bold"),bg="#9A9ACD",fg="black",cursor="hand2").place(x=1,y=330,height=85,width=197)
        btn_Currency_Type=Button(self.root,text=">>>>>>",font=("times new roman",20,"bold"),bg="#9A9ACD",fg="black",cursor="hand2").place(x=1,y=417,height=90,width=197)     
        
        #======Main frame Row1=====
        MainMenu=Frame(self.root,bd=2,relief=RIDGE,bg="#eef0ef")
        MainMenu.place(x=201,y=245,width=898,height=255)
        
        lbl_Payment_Type=Label(self.root,text="Payment Type:",font=("times new roman",15,"bold"),bg="light blue",fg="black").place(x=203,y=248,height=80,width=200)
        cmb_PaymentType=ttk.Combobox(self.root,textvariable=self.varPaymentType,values=("Select","Card","Cash","Other"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_PaymentType.place(x=383,y=248,height=80,width=500)
        cmb_PaymentType.current(0)              
        
        lbl_Payment_Ammount=Label(self.root,text="Payment Ammount",font=("times new roman",15,"bold"),bg="light blue",fg="black").place(x=203,y=332,height=80,width=200)
        txt_PaymentAmmount=Entry(self.root,textvariable=self.varPaymentAmmount,font=("goudy old style",20),bg="#d8d8d0",fg="green").place(x=387,y=332,height=80,width=510)
        
        lbl_Currency_Type=Label(self.root,text="Currency Type: ",font=("times new roman",15,"bold"),bg="light blue",fg="black").place(x=203,y=418,height=80,width=200)
        cmb_CurrencyType=ttk.Combobox(self.root,textvariable=self.varCurrencyType,values=("Select","Dollar","AFg","Euro","Yuan","Other"),state='readonly',justify=CENTER,font=("times new roman",15,"bold"))
        cmb_CurrencyType.place(x=383,y=418,height=80,width=500)
        cmb_CurrencyType.current(0)             
       
        #=====Btn========
        print=Button(self.root,text="Print",font=("times new roman",15,"bold"),bg="grey",fg="white",cursor="hand2").place(x=890,y=248,height=80,width=200)     
        clear=Button(self.root,text="Clear",command=self.clear,font=("goudy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=890,y=418,height=80,width=200)              
    
    
    def clear(self):
        self.varPaymentType.set("Select")
        self.varPaymentAmmount.set("")
        self.varCurrencyType.set("Select")
        self.show()             

    def search(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_searchby.get()=="Select":
                messagebox.showerror("Error","Select search by option", parent=self.root)
            elif self.var_searchtxt.get()=="":
                messagebox.showerror("Error","Search input required", parent=self.root)
            else:
                cur.execute("select * from members where "+self.var_searchby.get()+" LIKE '%"+self.var_searchtxt.get()+"%'")
                rows=cur.fetchall()
                if len(rows)!=0:
                    self.RoomsTable.delete(*self.RoomsTable.get_children())
                    for row in rows:
                        self.RoomsTable.insert('',END,values=row)
                else:
                    messagebox.showerror("Error","No Record Found!!!", parent=self.root)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
            



if __name__=="__main__":
    root=Tk()
    obj=paymentsClass(root)
    root.mainloop()

    
    