from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
from members import membersClass
from reserve import reserveClass
from contact import contactClass
from room import roomClass
from payments import paymentsClass
from contact import contactClass
import os
import sqlite3
import time

#########  Hotel booking system    #######################
class HBS:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1350x700+0+0")
        self.root.title("AUAF Room booking system | Developed in ITC 310 class")
        self.root.config(bg="#eef0ef")
        self.root.focus_force()
        #===title===#
        self.icon_title=PhotoImage(file="images/Bookroom.png")
        title=Label(self.root,text="AUAF Room Booking System",image=self.icon_title,compound=LEFT,font=("times new roman",40,"bold"),bg="#010c48",fg="white",anchor="w",padx=20).place(x=0,y=0,relwidth=1,height=70)
        
        #===btn_logout===#
        btn_logout=Button(self.root,text="Logout",command=self.logout,font=("times new roman",15,"bold"),bg="yellow",cursor="hand2").place(x=1150,y=10,height=50,width=150)
    
        #===Clock===#
        self.lbl_clock=Label(self.root,text="Welcome to AUAF Room Booking System\t\t Date: DD-MM-YYYY\t\t Time: HH:MM:SS",font=("times new roman",15),bg="#4d636d",fg="white")
        self.lbl_clock.place(x=0,y=70,relwidth=1,height=30)

        #====Left Menu====
        self.MenuLogo=Image.open("images/hotelstatus.png")
        self.MenuLogo=self.MenuLogo.resize((200,200),Image.ANTIALIAS)
        self.MenuLogo=ImageTk.PhotoImage(self.MenuLogo)
        
        LeftMenu=Frame(self.root,bd=2,relief=RIDGE, bg="white")
        LeftMenu.place(x=0,y=102,width=200,height=565)

        lbl_menuLogo=Label(LeftMenu,image=self.MenuLogo)
        lbl_menuLogo.pack(side=TOP,fill=X)
        
        self.icon_side=PhotoImage(file="images/side.png")
        
        lbl_menu=Label(LeftMenu,text="Menu",font=("times new roman",20),bg="#009688").pack(side=TOP,fill=X)
        
        btn_Members=Button(LeftMenu,text="Members",command=self.members,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_Rooms=Button(LeftMenu,text="Rooms",command=self.room,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_Reserve=Button(LeftMenu,text="Reserve",command=self.reserve,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_Payments_info=Button(LeftMenu,text="Payments",command=self.payment,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_Contacts=Button(LeftMenu,text="Contacts",command=self.contact,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)
        btn_Exit=Button(LeftMenu,text="Exit",command=self.Exit,font=("times new roman",20,"bold"),bg="white",bd=3,cursor="hand2").pack(side=TOP,fill=X)


        #===Content===
        
        self.lbl_Members=Label(self.root,text="Members\n[ 0 ]",bd=5,relief=RIDGE,bg="#33bbf9",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Members.place(x=300,y=120,height=150,width=300)
        
        self.lbl_Rooms=Label(self.root,text="Rooms\n[ 0 ]",bd=5,relief=RIDGE,bg="#ff5722",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Rooms.place(x=650,y=120,height=150,width=300)
        
        self.lbl_Reserve=Label(self.root,text="Reserve\n[ 0 ]",bd=5,relief=RIDGE,bg="#009688",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Reserve.place(x=1000,y=120,height=150,width=300)
        
        self.lbl_Payments_info=Label(self.root,text="Payments_info\n[ 0 ]",bd=5,relief=RIDGE,bg="#607d8b",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Payments_info.place(x=300,y=300,height=150,width=300)
        
        self.lbl_Contacts=Label(self.root,text="Contacts\n[ 0 ]",bd=5,relief=RIDGE,bg="#ffc107",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Contacts.place(x=650,y=300,height=150,width=300)
        
        self.lbl_Exit=Label(self.root,text="Exit\n[ 0 ]",bd=5,relief=RIDGE,bg="#33bbf9",fg="white",font=("goudy old style",20,"bold"))
        self.lbl_Exit.place(x=1000,y=300,height=150,width=300)


        #===footer===#
        lbl_footer=Label(self.root,text="AUAF Room Booking System | Developed in ITC 310 clsss \n For any Technical Issue Contact:+905527490843",font=("times new roman",12),bg="#4d636d",fg="white").pack(side=BOTTOM,fill=X)

        self.update_content()
#=============================================

    def members(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=membersClass(self.new_win)
        
    def reserve(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=reserveClass(self.new_win)
    
    def room(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=roomClass(self.new_win)
    
    def contact(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=contactClass(self.new_win)
        
    def payment(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=paymentsClass(self.new_win)

    def update_content(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            cur.execute("select * from members")
            members=cur.fetchall()
            self.lbl_Members.config(text=f'Members\n[ {str(len(members))} ]')
           
            cur.execute("select * from contact")
            contact=cur.fetchall()
            self.lbl_Contacts.config(text=f'Contacts\n[ {str(len(contact))} ]')
           
            cur.execute("select * from payments")
            payments=cur.fetchall()
            self.lbl_Payments_info.config(text=f'Payments_info\n[ {str(len(payments))} ]')
           
            cur.execute("select * from Reserve")
            Reserve=cur.fetchall()
            self.lbl_Reserve.config(text=f'Admin Reserve\n[ {str(len(Reserve))} ]')
           
            cur.execute("select * from Rooms")
            Rooms=cur.fetchall()
            self.lbl_Rooms.config(text=f'Rooms\n[ {str(len(Rooms))} ]')
          
            time_=time.strftime("%I:%M:%S")
            date_=time.strftime("%d-%m-%Y")
            self.lbl_clock.config(text=f"Welcome to AUAF Room Booking System\t\t Date: {str(date_)}\t\t Time: {str(time_)}")
            self.lbl_clock.after(200,self.update_content)
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
       
    
    def logout(self):
        self.root.destroy()
        os.system("python login.py")
        
    def Exit(self):
        self.root.destroy()
    
if __name__=="__main__":
    root=Tk()
    obj=HBS(root)
    root.mainloop()

    
    