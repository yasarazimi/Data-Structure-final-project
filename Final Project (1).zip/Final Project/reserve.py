from tkinter import*
from PIL import Image, ImageTk 
from tkinter import ttk,messagebox
import sqlite3
class reserveClass:
    def __init__(self, root):
        self.root=root
        self.root.geometry("1100x450+220+130")
        self.root.title("AUAF Room booking system | Developed in ITC 310 clsss")
        self.root.config(bg="white")
        self.root.focus_force()
        #==================================
        # All Variables=====
        self.var_RoomId=StringVar()
        
        self.var_firstname=StringVar()
        self.var_middlename=StringVar()
        self.var_lastname=StringVar()
        self.var_contactnumber=StringVar()
        self.var_email=StringVar()
        self.var_password=StringVar()
        self.var_numberofstudents=StringVar()
        self.var_numberofteachers=StringVar()  
        self.var_numberofhoursofstay=StringVar()  
        self.var_roomnumber=StringVar()       
        self.var_RoomType=StringVar()           
        #====content=====
        #======Row1=====
        #===title===
        title=Label(self.root,text="Personal Information",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=50,y=9,width=1000)
        
        lbl_firstname=Label(self.root,text="First Name",font=("goudy old style",15),bg="white").place(x=45,y=50)
        lbl_middlename=Label(self.root,text="Middle Name",font=("goudy old style",15),bg="white").place(x=350,y=50)
        lbl_lastname=Label(self.root,text="Last Name",font=("goudy old style",15),bg="white").place(x=750,y=50)
        
        txt_firstname=Entry(self.root,textvariable=self.var_firstname,font=("goudy old style",15),bg="lightyellow").place(x=150,y=50,width=180)
        txt_middlename=Entry(self.root,textvariable=self.var_middlename,font=("goudy old style",15),bg="lightyellow").place(x=500,y=50,width=180)
        txt_lastname=Entry(self.root,textvariable=self.var_lastname,font=("goudy old style",15),bg="lightyellow").place(x=850,y=50,width=180)
        #======Row2=====
        #===title2===
        title2=Label(self.root,text="Contact Information",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=50,y=90,width=1000)
        lbl_contact=Label(self.root,text="Contact",font=("goudy old style",15),bg="white").place(x=50,y=130)
        lbl_Email=Label(self.root,text="Email",font=("goudy old style",15),bg="white").place(x=350,y=130)
        lbl_password=Label(self.root,text="Password",font=("goudy old style",15),bg="white").place(x=750,y=130)
        
        txt_contact=Entry(self.root,textvariable=self.var_contactnumber,font=("goudy old style",15),bg="lightyellow").place(x=150,y=130,width=180)
        txt_Email=Entry(self.root,textvariable=self.var_email,font=("goudy old style",15),bg="lightyellow").place(x=500,y=130,width=180)
        txt_password=Entry(self.root,textvariable=self.var_password,font=("goudy old style",15),bg="lightyellow").place(x=850,y=130,width=180)

        #======Row3=====
        #===title2===
        title3=Label(self.root,text="Reserve Information",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=50,y=170,width=1000)
       
        lbl_numberofstudents=Label(self.root,text="Amount of Stud",font=("goudy old style",15),bg="white").place(x=10,y=210)
        lbl_numberofteachers=Label(self.root,text="Amount of Teacher",font=("goudy old style",15),bg="white").place(x=330,y=210)
        lbl_numberofhoursofstay=Label(self.root,text="Amount of Time",font=("goudy old style",15),bg="white").place(x=700,y=210)
        
        txt_var_numberofstudents=Entry(self.root,textvariable=self.var_numberofstudents,font=("goudy old style",15),bg="lightyellow").place(x=150,y=210,width=180)
        txt_numberofteachers=Entry(self.root,textvariable=self.var_numberofteachers,font=("goudy old style",15),bg="lightyellow").place(x=500,y=210,width=180)
        txt_numberofhoursofstay=Entry(self.root,textvariable=self.var_numberofhoursofstay,font=("goudy old style",15),bg="lightyellow").place(x=850,y=210,width=180)

        #======Row4=====
        title4=Label(self.root,text="Room Information",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=50,y=250,width=1000)
       
        lbl_roomnumber=Label(self.root,text="Room Number",font=("goudy old style",15),bg="white").place(x=10,y=290)
        txt_roomnumber=Entry(self.root,textvariable=self.var_roomnumber,font=("goudy old style",15),bg="lightyellow").place(x=150,y=290)
        lbl_roomType=Label(self.root,text="Room Type",font=("goudy old style",15),bg="white").place(x=330,y=290)
        cmb_roomType=ttk.Combobox(self.root,textvariable=self.var_RoomType,values=("Select","Main Hall","Exam Hall","Lecture Room","Tutorial Room","Design Studio","Meeting Room"),state='readonly',justify=CENTER,font=("goudy old style",15))
        cmb_roomType.place(x=440,y=290,width=180)
        cmb_roomType.current(0)              
        
        lbl_RoomId=Label(self.root,text="RoomId",font=("times new roman",15,"bold"),bg="white").place(x=203,y=370) 
        txt_RoomId=Entry(self.root,textvariable=self.var_RoomId,font=("times new roman",15,"bold"),bg="lightyellow").place(x=280,y=370,width=150,height=30)
    
        #======Button=====
        title5=Label(self.root,text="Choose one of the operations",font=("goudy old style",15),bg="#0f4d7d",fg="white").place(x=40,y=330,width=1000)
       
        btn_Reserve=Button(self.root,text="Reserve",command=self.Reserve,font=("goudy old style",15),bg="#2196f3",fg="white",cursor="hand2").place(x=40,y=380,width=110,height=28)
    #    btn_Unreserve=Button(self.root,text="Unreserve",command=self.update,font=("goudy old style",15),bg="#4caf50",fg="white",cursor="hand2").place(x=300,y=380,width=110,height=28)
        btn_Delete=Button(self.root,text="Delete",command=self.delete,font=("goudy old style",15),bg="#f44336",fg="white",cursor="hand2").place(x=560,y=380,width=110,height=28)
        btn_Clear=Button(self.root,text="Clear",command=self.clear,font=("goudy old style",15),bg="#607d8b",fg="white",cursor="hand2").place(x=820,y=380,width=110,height=28)
        
        
       #=================================
    def Reserve(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_RoomId.get()=="":
                messagebox.showerror("Error","RoomId Must be required",parent=self.root)
            else:
                cur.execute("Select * from Reserve where RoomId=?",(self.var_RoomId.get(),))
                row=cur.fetchone()
                if row!=None:
                    messagebox.showerror("Error","This Room already Assigned Try a different roomiD",parent=self.root)
                else:
                    cur.execute("Insert into Reserve(RoomId,FirstName,Middlename,LastName,Contact,Email,Password,AmountofStud,AmountofTeacher,AmountofTime,RoomType) values(?,?,?,?,?,?,?,?,?,?,?)",(
                                        self.var_RoomId.get(),
                                        self.var_RoomType.get(),
                                        self.var_firstname.get(),
                                        self.var_middlename.get(),
                                        self.var_lastname.get(),
                                        self.var_email.get(),
                                        self.var_password.get(),
                                        self.var_numberofstudents.get(),
                                        self.var_numberofteachers.get(),
                                        self.var_numberofhoursofstay.get(),
                                        self.var_contactnumber.get(),
                    ))
                    con.commit()
                    messagebox.showinfo("success","Room added successfully",parent=self.root)
                    # self.show()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
    def add(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_roomnumber.get()=="":
                messagebox.showerror("Error","roomnumber required",parent=self.root)
            else:
                cur.execute("Select * from reserve where roomnumber=?",(self.var_roomnumber.get(),))
                row=cur.fetchone()
                if row!=None:
                    messagebox.showerror("Error","This Employess Room is already Booked Try a different Room",parent=self.root)
                else:
                    cur.execute("Insert into reserve(firstname,middlename,lastname,contactnumber,email,password,numberofstudents,numberofteachers,numberofhoursofstay,roomnumber,RoomType) values(?,?,?,?,?,?,?,?,?,?,?)",(
                                        self.var_firstname.get(),
                                        self.var_middlename.get(),
                                        self.var_lastname.get(),
                                        self.var_contactnumber.get(),
                                        
                                        self.var_email.get(),
                                        self.var_password.get(),
                                        
                                        self.var_numberofstudents.get(),
                                        self.var_numberofteachers.get(),
                                        self.var_numberofhoursofstay.get(),
                                        self.var_roomnumber.get(),
                                        self.var_RoomType.get(),
                    ))    

                    con.commit()
                    messagebox.showinfo("success","Reservation added successfully",parent=self.root)
                   
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
        
         
        self.var_firstname.set(row[0])
        self.var_middlename.set(row[1])
        self.var_lastname.set(row[2])
        self.var_contactnumber.set(row[3])
                                        
        self.var_email.set(row[4])
        self.var_password.set(row[5])
                                        
        self.var_numberofstudents.set(row[6])
        self.var_numberofteachers.set(row[7])
        self.var_numberofhoursofstay.set(row[8])
        self.var_roomnumber.set(row[8])
        self.var_RoomType.set(row[8])                
        
    def update(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_roomnumber.get()=="":
                messagebox.showerror("Error","roomnumber is required",parent=self.root)
            else:
                cur.execute("Select * from reserve where roomnumber=?",(self.var_roomnumber.get(),))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Booked Room ",parent=self.root)
                else:
                    cur.execute("Update reserve set firstname=?,middlename=?,lastname=?,contactnumber=?,email=?,numberofstudents=?,numberofteachers=?,numberofhoursofstay=?,roomnumber=?,RoomType=? where roomnumber=?",(
                                        self.var_firstname.get(),
                                        self.var_middlename.get(),
                                        self.var_lastname.get(),
                                        self.var_contactnumber.get(),
                                        
                                        self.var_email.get(),
                                        self.var_password.get(),
                                        
                                        self.var_numberofstudents.get(),
                                        self.var_numberofteachers.get(),
                                        self.var_numberofhoursofstay.get(),
                                        self.var_RoomType.get(),
                                        self.var_roomnumber.get(),
                                        
                    ))
                    con.commit()
                    messagebox.showinfo("success","Reservation Updated successfully",parent=self.root)
                 

        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
        
    def delete(self):
        con=sqlite3.connect(database=r'Final Project.db')
        cur=con.cursor()
        try:
            if self.var_RoomId.get()=="":
                messagebox.showerror("Error","roomId is required",parent=self.root)
            else:
                cur.execute("Select * from reserve where RoomId=?",(self.var_RoomId.get(),))
                row=cur.fetchone()
                if row==None:
                    messagebox.showerror("Error","Wrong Room ID",parent=self.root)
                else:
                    op=messagebox.askyesno("Confirm","Do you really want to delete this data?",parent=self.root)
                    if op==True:
                        cur.execute("delete from reserve where RoomId=?",(self.var_RoomId.get(),))
                        con.commit()
                        messagebox.showinfo("Delete","Reservation Deleted successfully",parent=self.root)
                        self.clear()
        except Exception as ex:
            messagebox.showerror("Error",f"Error due to : {str(ex)}",parent=self.root)
           
    def clear(self):
        self.var_firstname.set("")
        self.var_middlename.set("")
        self.var_lastname.set("")
        self.var_contactnumber.set("")
                                        
        self.var_email.set("")
        self.var_password.set("")
        self.var_roomnumber.set("")
                                        
        self.var_numberofstudents.set("")
        self.var_numberofteachers.set("")
        self.var_numberofhoursofstay.set("")
        self.var_RoomId.set("")
        self.var_RoomType.set("Select")
                  


if __name__=="__main__":
    root=Tk()
    obj=reserveClass(root)
    root.mainloop()

    
    